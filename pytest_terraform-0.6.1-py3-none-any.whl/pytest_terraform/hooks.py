def pytest_terraform_modify_state(tfstate):
    """ called before tfstate is saved to disk """
