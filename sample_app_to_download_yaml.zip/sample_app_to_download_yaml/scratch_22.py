from io import BytesIO

import yaml
from flask import Flask, send_file, render_template
from flask_cors import CORS

app = Flask(__name__)
CORS(app=app)


@app.route('/create_yaml')
def create_yaml_file():
    data = {
        'a': ['contains', 'something'],
    }
    memory_file = BytesIO()
    memory_file.write(bytes(yaml.dump(data=data, default_flow_style=False), 'utf-8'))
    memory_file.seek(0)
    return send_file(memory_file, as_attachment=True, attachment_filename='file.yaml')


@app.route('/index')
def index():
    return render_template('scratch_23.html')


if __name__ == '__main__':
    app.run()
